package com.example.MongoSpring.repository;

public class MongoRepository<T1, T2> {

}
